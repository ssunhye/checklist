-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: localhost    Database: checklist
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `filter`
--

DROP TABLE IF EXISTS `filter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `filter` (
  `category` varchar(30) DEFAULT NULL,
  `condition` json DEFAULT NULL,
  KEY `idx_filter_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filter`
--

LOCK TABLES `filter` WRITE;
/*!40000 ALTER TABLE `filter` DISABLE KEYS */;
INSERT INTO `filter` VALUES ('Coffeemachine','{\"가격대\": [\"전체\", \"~10만원\", \"10~20만원\", \"20~30만원\", \"30만원~\"], \"물통용량\": [\"전체\", \"~0.6L\", \"0.6~0.8L\", \"0.8~1L\", \"1L~\"], \"예열시간\": [\"전체\", \"~30초\", \"~40초\", \"~50초\"], \"펌프압력\": [\"전체\", \"15bar\", \"19bar\"]}'),('Monitor','{\"가격대\": [\"전체\", \"~20만원\", \"20~25만원\", \"25~30만원\", \"30~40만원\", \"40만원~\"], \"주사율\": [\"전체\", \"60Hz\", \"75Hz\", \"100Hz\", \"120Hz\", \"144Hz\", \"155Hz\"], \"해상도\": [\"전체\", \"FHD\", \"QHD\", \"4K UHD\"], \"화면 크기\": [\"전체\", \"20인치\", \"24인치\", \"27인치\", \"32인치\", \"37인치\"]}'),('Aircleaner','{\"가격대\": [\"전체\", \"~10만원\", \"10~20만원\", \"20~30만원\", \"30~40만원\", \"40~50만원\", \"50~70만원\", \"70만원~\"], \"사용면적\": [\"전체\", \"~17㎡(5평)\", \"17~33㎡(5~10평)\", \"33~50㎡(10~15평)\", \"50~66㎡(15~20평)\", \"66~83㎡(20-25평)\", \"83~99㎡(25-30평)\"], \"필터 타입\": [\"전체\", \"필터\", \"음이온\", \"산소발생\", \"산림욕\", \"촉매식\", \"전기집진식\"], \"미세먼지필터링\": [\"전체\", \"O\", \"X\"]}'),('Airfryer','{\"용량\": [\"전체\", \"~2L\", \"2~5L\", \"5~7L\", \"7~20L\", \"20L~\"], \"형태\": [\"바스켓형\", \"오븐형\"], \"가격대\": [\"전체\", \"~5만원\", \"5~10만원\", \"10~15만원\", \"20만원~\"], \"소비전력\": [\"~1300W\", \"1300~1500W\", \"1500~1800W\", \"1800W~\"]}');
/*!40000 ALTER TABLE `filter` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-08  7:21:15
